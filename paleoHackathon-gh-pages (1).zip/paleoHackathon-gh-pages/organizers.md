# Organizers

<img src="images/julien.jpg" alt="Emile-Geay" width="100" />

[Julien Emile-Geay](https://scholar.google.com/citations?hl=en&user=OVti4jEAAAAJ&view_op=list_works&sortby=pubdate), Department of Earth Sciences, University of Southern California
---
<img src="images/deborah.jpg" alt="Khider" width="100" />

[Deborah Khider](https://www.isi.edu/people/dkhider/about), Information Sciences Institute, University of Southern California
---
<img src="images/nick.jpeg" alt="McKay" width="100" />

[Nick McKay](https://directory.nau.edu/person/npm4), School of Earth and Sustainability, Northern Arizona University
---
<img src="images/feng.jpg" alt="Zhu" width="100" />

[Feng Zhu](https://earth.usc.edu/~fengzhu/), Department of Earth Sciences, University of Southern California
---
<img src="images/alex.png" alt="James" width="100" />

Alexander James, Department of Earth Sciences, University of Southern California
