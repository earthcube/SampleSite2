# Overview schedule

Tentative Schedule. Links to Zoom sessions will be emailed privately.

## All times are in PST (Los Angeles time)

### Day 1

| Start | End | Session | Speaker |
| ---- | ---- | --------- | ------------------- |   
| 09:00 | 09:30 | Icebreaker  | J. Emile-Geay |
|09:30|10:00| Linked Paleo Data | N. McKay|
|10:10|10:40| Pyleoclim overview| D. Khider|
|10:45|11:30| Hackathon roadmap | J. Emile-Geay |
|11:30|12:00| Guided practicums | J. Emile-Geay |
|13:00|16:00| Self-guided practicums| Teams |

### Day 2

| Start | End | Session | Speaker |
| ---- | ---- | --------- | ------------------- |   
| 09:00 | 12:00 | Self-guided practicums| Teams|
|13:00|14:45|Presentations: take-homes from Pyleoclim| Teams|
|15:00|15:45|Beyond the hub| D. Khider, F. Zhu|
|15:45|16:00|Concluding remarks| J. Emile-Geay|
